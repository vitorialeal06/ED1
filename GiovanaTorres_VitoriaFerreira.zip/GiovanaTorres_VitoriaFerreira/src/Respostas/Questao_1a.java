package Respostas;

public class Questao_1a {

	public static void main(String[] args) {
		int nota = 0;
		if (nota>0 && nota<10) {
			System.out.println("OK!");
		}else
			System.out.println("Erro!");
	}

}
