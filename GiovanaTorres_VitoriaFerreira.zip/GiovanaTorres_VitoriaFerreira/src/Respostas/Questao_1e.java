package Respostas;

public class Questao_1e {

	public static void main(String[] args) {
		int n = 0, i = 2, fat = 1;
		
		do {
			fat = fat * i;
			i ++;
		}while(i > n);
	}

}
