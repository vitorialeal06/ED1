package Respostas.Heranca_02;

public class TestVeiculo {
	public static void main(String[] args) {
		Caminhao caminhao = new Caminhao("we", 123, 34);
		caminhao.exibirDados();
		Onibus onibus = new Onibus("we", 123, 24);
		onibus.exibirDados();
		
		
	}

}
