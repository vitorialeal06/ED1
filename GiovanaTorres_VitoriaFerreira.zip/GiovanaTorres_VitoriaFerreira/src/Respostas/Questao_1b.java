package Respostas;

public class Questao_1b {

	public static void main(String[] args) {
		int a = 0;
		int b = 0;
		
		while (a != b) {
			if (a>b) {
				a=a-b;
			}else {
				b = b - a;
			}
		}
	
	}

}
