package Respostas;

public class Questao_1c {

	public static void main(String[] args) {
		int x = 0;
		int conta = 0;
		
		if (x%2 == 0) {
			conta ++;
		}
	}

}
