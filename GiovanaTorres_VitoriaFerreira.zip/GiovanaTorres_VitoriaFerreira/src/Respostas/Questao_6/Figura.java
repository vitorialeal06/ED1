package Respostas.Questao_6;

public abstract class Figura {
	private String cor;

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}
	

} 
