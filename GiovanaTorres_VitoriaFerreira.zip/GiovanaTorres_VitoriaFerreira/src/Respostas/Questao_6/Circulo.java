package Respostas.Questao_6;

public class Circulo extends Figura {

	private double raio;

	public double getRaio() {
		return raio;
	}

	public void setRaio(double base) {
		this.raio = base;
	}
	
	
	Triangulo(double raio, String cor){
		super(cor);
		this.raio = raio;
		
	}
	
	double area() {
		return Math.PI * raio*raio;
	}
	
	double getDiametro() {
		return raio*raio;
	}
	
	public String toString() {
		return String.format("area do circulo: .2f", area());
	}
	
	

}
