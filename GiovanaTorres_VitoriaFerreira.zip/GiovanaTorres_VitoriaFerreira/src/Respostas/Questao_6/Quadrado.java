package Respostas.Questao_6;

public class Quadrado extends Retangulo{
	
	double lado;
	Quadrado(double lado, String cor){
		super(lado, cor);
		this.lado = lado;
	}
	
	public String toString() {
		return String.format("area do quadrado: .2f", area());
	}
}
