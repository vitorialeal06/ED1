package Respostas.Questao_6;

public class mainFigura {

	public static void main(String[] args) {
		Circulo circulo = new Triangulo(2, "a");
		circulo.area();
		circulo.toString();
		
	}

}
