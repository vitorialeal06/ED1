package Respostas.Questao_6;

public class Triangulo extends Figura {
	private double base;
	private double altura;
	public double getBase() {
		return base;
	}
	public void setBase(double base) {
		this.base = base;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}

	
	Triangulo(double base, double altura, String cor){
		super(cor);
		this.base = base;
		this.altura = altura;
	}
	
	Triangulo(double raio, String cor){
		super(cor);
		this.base = raio;
		
	
	}
	
	double area() {
		return (base*altura)/2;
	}
	
	public String toString() {
		return String.format("area do triangulo: .2f", area());
	}

}
